class PlagiarismRating < BinaryPercentRating
  def title
    "plagiarism"
  end

  def value
    -100
  end

end
