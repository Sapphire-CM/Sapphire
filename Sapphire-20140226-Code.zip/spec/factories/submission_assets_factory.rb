FactoryGirl.define do
  factory :submission_asset do
    submission nil
    file "My submission file PDF"
    submitted_at "2013-09-03 11:32:55"
  end
end
