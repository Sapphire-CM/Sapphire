require 'spec_helper'

describe SingleEvaluationsController do

end
