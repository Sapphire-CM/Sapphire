FactoryGirl.define do
  factory :student_group_registration do
    student_group
    exercise
  end
end
