BetterErrors.editor = :sublime if defined? BetterErrors
BetterErrors.use_pry! if defined? BetterErrors
