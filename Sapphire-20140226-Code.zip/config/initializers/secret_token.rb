# Be sure to restart your server when you modify this file.

# Your secret key is used for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!

# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
# You can use `rake secret` to generate a secure secret key.

# Make sure your secret_key_base is kept private
# if you're sharing your code publicly.
Sapphire::Application.config.secret_key_base = 'db5841a469c33589f83759e5df2310012d4e3ce7f0e5a40363a042b1737021f90221cbef53b61543a2524aca505fb22a254a7f9ac6f7869084345dcc8b540f78'
