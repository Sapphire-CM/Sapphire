Sapphire::AutomatedCheckers::Central.register Sapphire::AutomatedCheckers::EmailChecker
Sapphire::AutomatedCheckers::Central.register Sapphire::AutomatedCheckers::AssetCountChecker
Sapphire::AutomatedCheckers::Central.register Sapphire::AutomatedCheckers::DeadlineChecker
Sapphire::AutomatedCheckers::Central.register Sapphire::AutomatedCheckers::Ex31Checker
Sapphire::AutomatedCheckers::Central.register Sapphire::AutomatedCheckers::Ex5Checker
Sapphire::AutomatedCheckers::Central.register Sapphire::AutomatedCheckers::Ex5GraztimesStyleChecker
