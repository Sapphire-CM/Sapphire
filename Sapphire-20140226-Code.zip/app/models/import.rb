module Import
  def self.table_name_prefix
    'import_'
  end
end
