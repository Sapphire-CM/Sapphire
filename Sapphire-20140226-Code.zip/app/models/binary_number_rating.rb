class BinaryNumberRating < BinaryRating
  # if checked, value counts as follows:
  #  7  => total_value + 7
  # -3  => total_value + (-3)
end
