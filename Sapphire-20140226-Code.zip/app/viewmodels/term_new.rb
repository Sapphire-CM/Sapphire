class TermNew < Term

  attr_accessible :copy_elements, :source_term_id, :copy_lecturer, :copy_exercises, :copy_grading_scale
  attr_accessor :copy_elements, :source_term_id, :copy_lecturer, :copy_exercises, :copy_grading_scale

end
