require 'spec_helper'

describe SingleEvaluationsDecorator do
end
