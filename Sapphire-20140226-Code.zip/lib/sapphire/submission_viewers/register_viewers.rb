Sapphire::SubmissionViewers::Central.register Sapphire::SubmissionViewers::Ex4HTMLViewer
Sapphire::SubmissionViewers::Central.register Sapphire::SubmissionViewers::Ex5StylesheetViewer

