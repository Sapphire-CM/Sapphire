require 'spec_helper'

describe SubmissionViewersDecorator do
end
