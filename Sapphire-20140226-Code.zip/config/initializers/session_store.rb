# Be sure to restart your server when you modify this file.

Sapphire::Application.config.session_store :cookie_store, key: '_sapphire_session'
